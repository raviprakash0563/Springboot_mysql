package com.gfg.employeapp.SpringProject2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gfg.employeapp.SpringProject2.entity.Employee;

public interface EmployeeRepo extends JpaRepository <Employee, Integer>{

}
    
