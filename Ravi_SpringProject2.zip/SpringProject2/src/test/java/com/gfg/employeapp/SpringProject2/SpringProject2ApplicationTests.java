package com.gfg.employeapp.SpringProject2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
